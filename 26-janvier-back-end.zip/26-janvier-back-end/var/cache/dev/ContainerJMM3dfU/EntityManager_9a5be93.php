<?php

namespace ContainerJMM3dfU;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder1a107 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerf5723 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesd5119 = [
        
    ];

    public function getConnection()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'getConnection', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'getMetadataFactory', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'getExpressionBuilder', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'beginTransaction', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'getCache', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->getCache();
    }

    public function transactional($func)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'transactional', array('func' => $func), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->transactional($func);
    }

    public function commit()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'commit', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->commit();
    }

    public function rollback()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'rollback', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'getClassMetadata', array('className' => $className), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'createQuery', array('dql' => $dql), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'createNamedQuery', array('name' => $name), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'createQueryBuilder', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'flush', array('entity' => $entity), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'clear', array('entityName' => $entityName), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->clear($entityName);
    }

    public function close()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'close', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->close();
    }

    public function persist($entity)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'persist', array('entity' => $entity), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'remove', array('entity' => $entity), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'refresh', array('entity' => $entity), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'detach', array('entity' => $entity), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'merge', array('entity' => $entity), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'getRepository', array('entityName' => $entityName), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'contains', array('entity' => $entity), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'getEventManager', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'getConfiguration', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'isOpen', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'getUnitOfWork', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'getProxyFactory', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'initializeObject', array('obj' => $obj), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'getFilters', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'isFiltersStateClean', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'hasFilters', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return $this->valueHolder1a107->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerf5723 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder1a107) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder1a107 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder1a107->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, '__get', ['name' => $name], $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        if (isset(self::$publicPropertiesd5119[$name])) {
            return $this->valueHolder1a107->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder1a107;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder1a107;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder1a107;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder1a107;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, '__isset', array('name' => $name), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder1a107;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder1a107;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, '__unset', array('name' => $name), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder1a107;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder1a107;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, '__clone', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        $this->valueHolder1a107 = clone $this->valueHolder1a107;
    }

    public function __sleep()
    {
        $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, '__sleep', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;

        return array('valueHolder1a107');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerf5723 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerf5723;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerf5723 && ($this->initializerf5723->__invoke($valueHolder1a107, $this, 'initializeProxy', array(), $this->initializerf5723) || 1) && $this->valueHolder1a107 = $valueHolder1a107;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder1a107;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder1a107;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
